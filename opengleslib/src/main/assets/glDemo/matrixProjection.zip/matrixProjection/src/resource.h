//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by matrixProjection.rc
//
#define IDD_FORMVIEW                    101
#define IDD_ABOUT                       102
#define IDB_SONGHO                      103
#define IDB_PERSPECTIVE                 106
#define IDB_ORTHO                       107
#define IDC_RADIO_PERSPECTIVE           1001
#define IDC_RADIO_ORTHO                 1002
#define IDC_BUTTON_RESET                1009
#define IDC_SPIN_LEFT                   1010
#define IDC_SPIN_RIGHT                  1011
#define IDC_SPIN_BOTTOM                 1012
#define IDC_SPIN_TOP                    1013
#define IDC_SPIN_NEAR                   1014
#define IDC_SPIN_FAR                    1015
#define IDC_OK                          1018
#define IDC_RADIO_FILL                  1033
#define IDC_RADIO_LINE                  1034
#define IDC_RADIO_POINT                 1035
#define IDC_SLIDER_LEFT                 1036
#define IDC_SLIDER_RIGHT                1037
#define IDC_SLIDER_BOTTOM               1038
#define IDC_SLIDER_TOP                  1039
#define IDC_SLIDER_NEAR                 1040
#define IDC_SLIDER_FAR                  1041
#define IDC_LABEL_LEFT                  1042
#define IDC_LABEL_RIGHT                 1043
#define IDC_LABEL_BOTTOM                1044
#define IDC_LABEL_TOP                   1045
#define IDC_LABEL_NEAR                  1046
#define IDC_LABEL_FAR                   1047
#define IDC_BUTTON_ABOUT                1048
#define IDC_LINK1                       1049
#define IDC_PICTURE_MATRIX              1050
#define IDC_M0                          1100
#define IDC_M1                          1101
#define IDC_M2                          1102
#define IDC_M3                          1103
#define IDC_M4                          1104
#define IDC_M5                          1105
#define IDC_M6                          1106
#define IDC_M7                          1107
#define IDC_M8                          1108
#define IDC_M9                          1109
#define IDC_M10                         1110
#define IDC_M11                         1111
#define IDC_M12                         1112
#define IDC_M13                         1113
#define IDC_M14                         1114
#define IDC_M15                         1115

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
